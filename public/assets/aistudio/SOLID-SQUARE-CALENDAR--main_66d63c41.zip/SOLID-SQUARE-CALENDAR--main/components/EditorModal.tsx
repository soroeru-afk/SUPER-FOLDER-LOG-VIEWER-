"use client";
import { useState, useRef, useEffect, useCallback } from "react";
import { LogFile } from "@/lib/fs";
import { motion, AnimatePresence } from "motion/react";
import { Theme, getThemeColors } from "@/lib/theme";
import Markdown from "react-markdown";
import remarkGfm from "remark-gfm";
import {
  AlignLeft,
  AlignCenter,
  AlignRight,
  X,
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  Play,
  Square,
} from "lucide-react";

export function EditorModal({
  log,
  onClose,
  onSave,
  isFallbackMode,
  theme,
  textSize,
  setEditorTextSize,
  textFont,
  editorMaxWidth = 760,
  setEditorMaxWidth,
  editorLineHeight = 1.75,
  setEditorLineHeight,
  speechVoice = "Ichiro",
  speechRate = 2.0,
  speechVolume = 1.0,
  speechPitch = 1.0,
  onNavigate,
  hasPrev,
  hasNext,
}: any) {
  const [content, setContent] = useState(log.content || "");
  
  useEffect(() => {
    setContent(log.content || "");
    setIsEditing(log.isNew || false);
  }, [log]);

  const [textAlign, setTextAlign] = useState<"left" | "center" | "right">(
    "left",
  );
  const [isVertical, setIsVertical] = useState(() => localStorage.getItem("solid-square-is-vertical") === "true");
  const [isPaperMode, setIsPaperMode] = useState(() => localStorage.getItem("solid-square-is-paper") === "true");
  
  useEffect(() => {
    localStorage.setItem("solid-square-is-vertical", String(isVertical));
  }, [isVertical]);
  
  useEffect(() => {
    localStorage.setItem("solid-square-is-paper", String(isPaperMode));
  }, [isPaperMode]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isEditing, setIsEditing] = useState(log.isNew || false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const previewRef = useRef<HTMLDivElement>(null);
  const scrollRef = useRef<number | null>(null);

  const getScrollEl = useCallback(() => {
    return isEditing ? textareaRef.current : previewRef.current;
  }, [isEditing]);

  const startScroll = (direction: -1 | 1) => {
    const el = getScrollEl();
    if (!el) return;
    const scrollStep = () => {
      const currentEl = getScrollEl();
      if (currentEl) {
        currentEl.scrollBy({ left: direction * 10 });
      }
      scrollRef.current = requestAnimationFrame(scrollStep);
    };
    scrollStep();
  };

  const stopScroll = () => {
    if (scrollRef.current !== null) {
      cancelAnimationFrame(scrollRef.current);
      scrollRef.current = null;
    }
  };

  const scrollToBeginning = useCallback(() => {
    const el = getScrollEl();
    if (!el) return;
    if (isVertical) {
      // 縦書き (vertical-rl) の先頭は文章の書き始め (右端)
      el.scrollLeft = 0;
      el.scrollTo({ left: 0, behavior: "instant" });
    } else {
      // 横書きの先頭 (上端)
      el.scrollTop = 0;
      el.scrollTo({ top: 0, behavior: "instant" });
    }
  }, [isVertical, getScrollEl]);

  const scrollToEnd = useCallback(() => {
    const el = getScrollEl();
    if (!el) return;
    if (isVertical) {
      // 縦書き (vertical-rl) の末尾は文章の終わり (左端)
      // 現代ブラウザ (Chromium, Safari, Firefox) は -scrollWidth
      el.scrollLeft = -el.scrollWidth;
      el.scrollTo({ left: -el.scrollWidth, behavior: "instant" });
    } else {
      // 横書きの末尾 (下端)
      el.scrollTop = el.scrollHeight;
      el.scrollTo({ top: el.scrollHeight, behavior: "instant" });
    }
  }, [isVertical, getScrollEl]);

  // Speech Synthesis
  const speakText = (text: string) => {
    window.speechSynthesis.cancel();
    if (!text.trim()) return;

    const utterance = new SpeechSynthesisUtterance(text);
    const voices = window.speechSynthesis.getVoices();
    const selectedVoice =
      voices.find((v) => v.name === speechVoice) ||
      voices.find((v) => v.name.includes(speechVoice)) ||
      voices.find((v) => {
        const name = v.name.toLowerCase();
        if (speechVoice === "Ichiro" && (name.includes("ichiro") || name.includes("一郎"))) return true;
        if (speechVoice === "Haruka" && (name.includes("haruka") || name.includes("はるか") || name.includes("遥香"))) return true;
        if (speechVoice === "Ayumi" && (name.includes("ayumi") || name.includes("あゆみ"))) return true;
        if (speechVoice === "Ayaka" && (name.includes("ayaka") || name.includes("綾香"))) return true;
        return false;
      }) ||
      voices.find((v) => v.lang.includes("ja-JP")) ||
      voices.find((v) => v.lang.startsWith("ja"));

    if (selectedVoice) {
      utterance.voice = selectedVoice;
    }
    utterance.rate = speechRate;
    utterance.volume = speechVolume;
    utterance.pitch = speechPitch;

    utterance.onend = () => setIsPlaying(false);
    utterance.onerror = () => setIsPlaying(false);

    window.speechSynthesis.speak(utterance);
    setIsPlaying(true);
  };

  const toggleSpeech = () => {
    if (isPlaying) {
      window.speechSynthesis.cancel();
      setIsPlaying(false);
    } else {
      speakText(content);
    }
  };

  const handleTextareaClick = (e: React.MouseEvent<HTMLTextAreaElement>) => {
    if (isEditing) return;

    const textarea = e.currentTarget;
    if (textarea.selectionStart !== textarea.selectionEnd) {
      // User is selecting text, do not trigger audio
      return;
    }

    if (isPlaying) {
      window.speechSynthesis.cancel();
      setIsPlaying(false);
    } else {
      const clickPos = textarea.selectionStart;
      if (typeof clickPos === "number") {
        let textToRead = content.substring(clickPos);
        if (!textToRead.trim()) {
          textToRead = content;
        }
        speakText(textToRead);
      }
    }
  };

  useEffect(() => {
    return () => {
      window.speechSynthesis.cancel();
    };
  }, []);

  const handlePreviewClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (isEditing) return;

    const selection = window.getSelection();
    if (selection && selection.toString().trim().length > 0) {
      // ユーザーがテキスト選択中なら音声再生はトリガーしない
      return;
    }

    if (isPlaying) {
      window.speechSynthesis.cancel();
      setIsPlaying(false);
    } else {
      const previewEl = previewRef.current;
      if (!previewEl) return;

      let textToRead = "";
      let startNode: Node | null = null;
      let startOffset = 0;

      if (document.caretRangeFromPoint) {
        const pointRange = document.caretRangeFromPoint(e.clientX, e.clientY);
        if (pointRange && previewEl.contains(pointRange.startContainer)) {
          startNode = pointRange.startContainer;
          startOffset = pointRange.startOffset;
        }
      } else if ((document as any).caretPositionFromPoint) {
        const pos = (document as any).caretPositionFromPoint(e.clientX, e.clientY);
        if (pos && previewEl.contains(pos.offsetNode)) {
          startNode = pos.offsetNode;
          startOffset = pos.offset;
        }
      }

      if (startNode) {
        try {
          const range = document.createRange();
          range.setStart(startNode, startOffset);
          range.setEnd(previewEl, previewEl.childNodes.length);
          textToRead = range.toString();
        } catch {
          // ignore error
        }
      }

      // フォールバック: クリックされた要素(target)からpreviewElの末尾まで
      if (!textToRead.trim()) {
        const target = e.target as HTMLElement;
        if (previewEl.contains(target) && target !== previewEl) {
          try {
            const range = document.createRange();
            range.setStartBefore(target);
            range.setEnd(previewEl, previewEl.childNodes.length);
            textToRead = range.toString();
          } catch {
            // ignore error
          }
        }
      }

      if (!textToRead.trim()) {
        textToRead = previewEl.innerText || content;
      }

      if (textToRead.trim()) {
        speakText(textToRead);
      }
    }
  };

  // Handle vertical scroll with mouse wheel (supports both textarea and markdown preview)
  useEffect(() => {
    const el = isEditing ? textareaRef.current : previewRef.current;
    if (!el) return;

    const handleWheel = (e: WheelEvent) => {
      if (isVertical && e.deltaY !== 0) {
        e.preventDefault();
        // Since vertical-rl flow relies on horizontal scrolling, map deltaY to scrollLeft.
        // Scroll amount is adjusted for typical mouse wheel feel (reversed per user request)
        el.scrollLeft -= e.deltaY;
      }
    };

    el.addEventListener("wheel", handleWheel, { passive: false });

    return () => {
      el.removeEventListener("wheel", handleWheel);
    };
  }, [isVertical, isEditing]);

  // タイトルを動的に生成
  const displayTitle = (() => {
    const contentToSearch = content.trim();
    if (!contentToSearch) return "UNTITLED";
    // 改行、または日本語の句点、感嘆符、疑問符、あるいは英語の末尾記号（.+スペース）で句切る。
    const match = contentToSearch.match(
      /^[\s\S]*?(?:[。！？\n]|[.!?](?:\s|$))/,
    );
    if (match) {
      return match[0].trim();
    } else {
      return contentToSearch.trim();
    }
  })();

  const colors = getThemeColors(theme as Theme);
  const isPaperActive = isPaperMode;
  const panelBgClass = isPaperActive ? "bg-[#FAF6F0]" : colors.panelBg;
  const textMainClass = isPaperActive ? "text-[#181818]" : colors.textMain;
  const textDimClass = isPaperActive ? "text-black/30" : colors.textDim;

  const tableBorderColor = isPaperActive
    ? "border-[#c8c0b2]"
    : colors.borderStrong;

  // テーブル内フォントサイズ（本文文字サイズに連動して約88%に調整、極小化を防ぐため最低12px）
  const tableFontSize = Math.max(12, Math.round(textSize * 0.88));
  // テーブル内行間（本文の行間に心地よく追従しつつ、枠線内で詰まりすぎず間延びもしないバランス）
  const tableLineHeight = Math.max(1.2, Math.min(1.8, Number(editorLineHeight) * 0.88)).toFixed(2);
  const bodyLineHeight = Number(editorLineHeight);

  const markdownComponents = {
    table: ({ node, ...props }: any) => (
      <div
        className={
          isVertical
            ? "max-h-full inline-block mx-4 my-auto overflow-y-auto overflow-x-visible thin-scrollbar align-top"
            : "w-full my-4 overflow-x-auto thin-scrollbar"
        }
        style={{ writingMode: isVertical ? "vertical-rl" : "horizontal-tb" }}
      >
        <table
          className={`border-collapse border ${tableBorderColor} ${
            isVertical ? "max-h-full" : "w-full my-1"
          }`}
          style={{
            writingMode: isVertical ? "vertical-rl" : "horizontal-tb",
            fontSize: `${tableFontSize}px`,
            lineHeight: tableLineHeight,
          }}
          {...props}
        />
      </div>
    ),
    thead: ({ node, ...props }: any) => (
      <thead
        className={`${
          isVertical ? "border-l-2" : "border-b-2"
        } ${tableBorderColor} ${
          isPaperActive ? "bg-black/5" : colors.isDark ? "bg-white/5" : "bg-slate-100"
        } font-bold`}
        {...props}
      />
    ),
    tbody: ({ node, ...props }: any) => (
      <tbody className="divide-y divide-inherit" {...props} />
    ),
    tr: ({ node, ...props }: any) => (
      <tr
        className={`${
          isVertical ? "border-l" : "border-b"
        } ${tableBorderColor} transition-colors hover:bg-black/5 dark:hover:bg-white/5`}
        {...props}
      />
    ),
    th: ({ node, ...props }: any) => (
      <th
        className={`p-2.5 sm:p-3 font-bold border ${tableBorderColor} align-top tracking-wider whitespace-normal`}
        style={{
          writingMode: isVertical ? "vertical-rl" : "horizontal-tb",
          fontSize: `${tableFontSize}px`,
          lineHeight: tableLineHeight,
        }}
        {...props}
      />
    ),
    td: ({ node, ...props }: any) => (
      <td
        className={`p-2.5 sm:p-3 border ${tableBorderColor} align-top break-words whitespace-normal`}
        style={{
          writingMode: isVertical ? "vertical-rl" : "horizontal-tb",
          fontSize: `${tableFontSize}px`,
          lineHeight: tableLineHeight,
        }}
        {...props}
      />
    ),
    h1: ({ node, ...props }: any) => (
      <h1
        className={`font-bold tracking-wide ${
          isVertical
            ? "mx-4 my-0 pr-1.5 border-r border-current/20"
            : "my-4 mx-0 pb-1.5 border-b border-current/20"
        }`}
        style={{
          fontSize: `${Math.round(textSize * 1.35)}px`,
          lineHeight: Math.max(1.2, bodyLineHeight * 0.9),
        }}
        {...props}
      />
    ),
    h2: ({ node, ...props }: any) => (
      <h2
        className={`font-bold tracking-wide ${
          isVertical
            ? "mx-3.5 my-0 pr-1 border-r border-current/15"
            : "my-3 mx-0 pb-1 border-b border-current/15"
        }`}
        style={{
          fontSize: `${Math.round(textSize * 1.2)}px`,
          lineHeight: Math.max(1.2, bodyLineHeight * 0.9),
        }}
        {...props}
      />
    ),
    h3: ({ node, ...props }: any) => (
      <h3
        className={`font-bold tracking-wide ${
          isVertical ? "mx-3 my-0" : "my-2 mx-0"
        }`}
        style={{
          fontSize: `${Math.round(textSize * 1.08)}px`,
          lineHeight: bodyLineHeight,
        }}
        {...props}
      />
    ),
    h4: ({ node, ...props }: any) => (
      <h4
        className={`font-bold ${
          isVertical ? "mx-2 my-0" : "my-2 mx-0"
        }`}
        style={{
          fontSize: `${textSize}px`,
          lineHeight: bodyLineHeight,
        }}
        {...props}
      />
    ),
    p: ({ node, ...props }: any) => (
      <p
        className={`whitespace-pre-wrap break-words ${
          isVertical ? "mx-2.5 my-0" : "my-2.5 mx-0"
        }`}
        style={{
          fontSize: `${textSize}px`,
          lineHeight: bodyLineHeight,
        }}
        {...props}
      />
    ),
    ul: ({ node, ...props }: any) => (
      <ul
        className={`list-disc list-outside space-y-1 ${
          isVertical ? "mx-3 my-0 pt-6" : "my-3 mx-0 pl-6"
        }`}
        style={{
          fontSize: `${textSize}px`,
          lineHeight: bodyLineHeight,
        }}
        {...props}
      />
    ),
    ol: ({ node, ...props }: any) => (
      <ol
        className={`list-decimal list-outside space-y-1 ${
          isVertical ? "mx-3 my-0 pt-6" : "my-3 mx-0 pl-6"
        }`}
        style={{
          fontSize: `${textSize}px`,
          lineHeight: bodyLineHeight,
        }}
        {...props}
      />
    ),
    li: ({ node, ...props }: any) => (
      <li
        style={{
          lineHeight: bodyLineHeight,
        }}
        {...props}
      />
    ),
    strong: ({ node, ...props }: any) => (
      <strong className="font-bold opacity-100" {...props} />
    ),
    blockquote: ({ node, ...props }: any) => (
      <blockquote
        className={`opacity-80 italic ${
          isVertical
            ? `border-r-4 ${tableBorderColor} pr-3 mx-3 my-0`
            : `border-l-4 ${tableBorderColor} pl-3 py-1 my-3 mx-0`
        }`}
        style={{
          lineHeight: bodyLineHeight,
        }}
        {...props}
      />
    ),
    code: ({ node, inline, ...props }: any) => (
      <code
        className="bg-black/10 dark:bg-white/10 px-1.5 py-0.5 rounded font-mono text-[0.9em]"
        {...props}
      />
    ),
    hr: ({ node, ...props }: any) => (
      <hr
        className={`${
          isVertical
            ? `mx-6 border-r ${tableBorderColor} inline-block h-full align-top`
            : `my-6 border-t ${tableBorderColor}`
        }`}
        {...props}
      />
    ),
  };

  // Focus on mount
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.focus();
    }
  }, []);

  const handleSave = useCallback(() => {
    onSave(log, content);
  }, [onSave, log, content]);

  const increaseTextSize = () => {
    if (setEditorTextSize) setEditorTextSize(Math.min(textSize + 2, 72));
  };

  const decreaseTextSize = () => {
    if (setEditorTextSize) setEditorTextSize(Math.max(textSize - 2, 8));
  };

  // Handle Ctrl+S and Navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "s") {
        e.preventDefault();
        handleSave();
      }
      if (e.key === "Escape") {
        onClose();
      }
      
      // j, k and Home, End navigation when not editing text
      if (!isEditing && e.target instanceof HTMLElement) {
         const tagName = e.target.tagName.toLowerCase();
         if (tagName !== "textarea" && tagName !== "input") {
            if (e.key === "k" && hasNext && onNavigate) {
               e.preventDefault();
               onNavigate('NEXT');
            }
            if (e.key === "j" && hasPrev && onNavigate) {
               e.preventDefault();
               onNavigate('PREV');
            }
            if (e.key === "Home") {
               e.preventDefault();
               scrollToBeginning();
            }
            if (e.key === "End") {
               e.preventDefault();
               scrollToEnd();
            }
         }
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [content, log, handleSave, onClose, isEditing, hasPrev, hasNext, onNavigate, scrollToBeginning, scrollToEnd]);

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        transition={{ duration: 0.15, ease: "easeOut" }}
        className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-12"
      >
        {/* Backdrop */}
        <div
          className="absolute inset-0 bg-black/60 backdrop-blur-md"
          onClick={onClose}
        ></div>

        {/* Editor Wrapper (Theme Design) */}
        <div
          className={`relative w-full h-[95vh] max-w-[2400px] flex flex-col ${colors.panelBg} ${colors.shadowLg} overflow-hidden rounded-md`}
        >
          {/* Editor Header (Stealth UI) */}
          <div
            className={`relative flex-none flex flex-col px-6 pt-6 pb-4 ${colors.panelBg} shrink-0 border-b border-black/5 dark:border-white/5`}
          >
            {/* Close Button */}
            <button
              onClick={onClose}
              title="閉じる"
              className={`absolute top-3 right-3 z-50 ${colors.borderStrong} border px-1.5 py-0.5 rounded-sm ${colors.textSubHover} transition-colors flex items-center justify-center cursor-pointer`}
            >
              <X size={12} strokeWidth={2.5} />
            </button>

            {/* Title Display */}
            <div className="mb-4 pr-10 mt-1">
              <div
                className={`font-bold ${colors.textMain} whitespace-pre-wrap break-all`}
                style={{
                  fontSize: `${Math.max(18, textSize * 1.2)}px`,
                  fontFamily: textFont,
                  lineHeight: 1.4,
                  minHeight: "2.8em",
                }}
              >
                {displayTitle}
              </div>
              <div
                className={`mt-2 flex items-baseline gap-3 w-full`}
              >
                <span className={`flex-shrink-0 font-bold tracking-wider text-sm ${colors.textMain}`}>
                  {(() => {
                    const dStr = log.dateStr;
                    if (!dStr || dStr.length !== 8) return "";
                    const year = dStr.substring(0, 4);
                    const month = parseInt(dStr.substring(4, 6), 10);
                    const day = parseInt(dStr.substring(6, 8), 10);
                    if (theme === "JAPAN") {
                      return `${year}年${month}月${day}日`;
                    }
                    return `${year} / ${dStr.substring(4, 6)} / ${dStr.substring(6, 8)}`;
                  })()}
                </span>
                <span className={`text-[10px] ${colors.textSub} opacity-40 truncate`}>{log.name}</span>
              </div>
            </div>

            {/* Toolbar */}
            <div
              className={`flex items-center justify-between gap-x-4 gap-y-3 w-full text-[10px] uppercase tracking-wider ${colors.textMain} font-bold select-none flex-wrap overflow-x-auto no-scrollbar`}
            >
              <div className="flex items-center gap-3 flex-wrap">
                {/* Text Size Controls */}
                {setEditorTextSize && (
                  <div
                    className={`flex items-center gap-2 ${colors.borderStrong} border px-2 py-0.5 rounded-sm`}
                  >
                  <button
                    onClick={decreaseTextSize}
                    title="文字を小さく"
                    className={`${colors.textSubHover} hover:opacity-100 transition-colors px-1 font-mono`}
                  >
                    -
                  </button>
                  <span
                    className="font-mono w-[16px] text-center"
                    title="現在の文字サイズ"
                  >
                    {textSize}
                  </span>
                  <button
                    onClick={increaseTextSize}
                    title="文字を大きく"
                    className={`${colors.textSubHover} hover:opacity-100 transition-colors px-1 font-mono`}
                  >
                    +
                  </button>
                </div>
              )}

              {/* Layout Controls */}
              <div className="flex items-center gap-2">
                {setEditorMaxWidth && (
                  <div
                    className={`flex items-center gap-2 ${colors.borderStrong} border px-2 py-0.5 rounded-sm`}
                    title="幅"
                  >
                    <span className="opacity-50">W:</span>
                    <button
                      onClick={() =>
                        setEditorMaxWidth(Math.max(400, editorMaxWidth - 40))
                      }
                      className={`${colors.textSubHover} hover:opacity-100 transition-colors px-1 font-mono`}
                    >
                      -
                    </button>
                    <span className="font-mono w-[28px] text-center">
                      {editorMaxWidth}
                    </span>
                    <button
                      onClick={() =>
                        setEditorMaxWidth(Math.min(2400, editorMaxWidth + 40))
                      }
                      className={`${colors.textSubHover} hover:opacity-100 transition-colors px-1 font-mono`}
                    >
                      +
                    </button>
                  </div>
                )}

                {setEditorLineHeight && (
                  <div
                    className={`flex items-center gap-2 ${colors.borderStrong} border px-2 py-0.5 rounded-sm`}
                    title="行間"
                  >
                    <span className="opacity-50">LH:</span>
                    <button
                      onClick={() =>
                        setEditorLineHeight(
                          Math.max(
                            1,
                            Number((editorLineHeight - 0.1).toFixed(1)),
                          ),
                        )
                      }
                      className={`${colors.textSubHover} hover:opacity-100 transition-colors px-1 font-mono`}
                    >
                      -
                    </button>
                    <span className="font-mono w-[20px] text-center">
                      {editorLineHeight.toFixed(1)}
                    </span>
                    <button
                      onClick={() =>
                        setEditorLineHeight(
                          Math.min(
                            4,
                            Number((editorLineHeight + 0.1).toFixed(1)),
                          ),
                        )
                      }
                      className={`${colors.textSubHover} hover:opacity-100 transition-colors px-1 font-mono`}
                    >
                      +
                    </button>
                  </div>
                )}
              </div>
              </div>

              <div className="flex items-center gap-3 flex-wrap ml-auto">
                {/* Align Group */}
                <div className="flex items-center gap-4">
                <button
                  onClick={() => setTextAlign("left")}
                  title="左寄せ"
                  className={`${colors.borderStrong} border px-2 py-0.5 rounded-sm transition-colors ${textAlign === "left" ? colors.activeText + " " + colors.activeBg : colors.textSubHover}`}
                >
                  <AlignLeft size={14} strokeWidth={2.5} />
                </button>
                <button
                  onClick={() => setTextAlign("center")}
                  title="中央寄せ"
                  className={`${colors.borderStrong} border px-2 py-0.5 rounded-sm transition-colors ${textAlign === "center" ? colors.activeText + " " + colors.activeBg : colors.textSubHover}`}
                >
                  <AlignCenter size={14} strokeWidth={2.5} />
                </button>
                <button
                  onClick={() => setTextAlign("right")}
                  title="右寄せ"
                  className={`${colors.borderStrong} border px-2 py-0.5 rounded-sm transition-colors ${textAlign === "right" ? colors.activeText + " " + colors.activeBg : colors.textSubHover}`}
                >
                  <AlignRight size={14} strokeWidth={2.5} />
                </button>
              </div>

              <div className={`w-[1px] h-3 ${colors.borderStrong}`}></div>

              {/* Direction Group */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsVertical(false)}
                  title="横書き"
                  className={`${colors.borderStrong} border px-2 py-0.5 rounded-sm transition-colors ${!isVertical ? colors.activeText + " " + colors.activeBg : colors.textSubHover}`}
                >
                  HORIZ
                </button>
                <button
                  onClick={() => setIsVertical(true)}
                  title="縦書き"
                  className={`${colors.borderStrong} border px-2 py-0.5 rounded-sm transition-colors ${isVertical ? colors.activeText + " " + colors.activeBg : colors.textSubHover}`}
                >
                  VERT
                </button>
              </div>

              <div className={`w-[1px] h-3 ${colors.borderStrong}`}></div>

              <button
                onClick={() => setIsPaperMode(!isPaperMode)}
                title="ペーパーモード"
                className={`${colors.borderStrong} border px-2 py-0.5 rounded-sm transition-colors ${isPaperMode ? colors.activeText + " " + colors.activeBg : colors.textSubHover}`}
              >
                PAPER / {isPaperMode ? "ON" : "OFF"}
              </button>

              <div className={`w-[1px] h-3 ${colors.borderStrong}`}></div>

              {/* Play Button */}
              <button
                onClick={toggleSpeech}
                className={`flex items-center gap-2 ${colors.borderStrong} border px-3 py-0.5 rounded-sm ${isPlaying ? colors.activeText : ""} ${colors.bgHover} transition-colors`}
                title={isPlaying ? "STOP" : "VOICE"}
              >
                {isPlaying ? (
                  <Square size={12} fill="currentColor" />
                ) : (
                  <Play size={12} fill="currentColor" />
                )}
                <span>VOICE</span>
              </button>

              {/* Edit Toggle */}
              <button
                onClick={() => {
                  const nextState = !isEditing;
                  setIsEditing(nextState);
                  if (nextState) {
                    setTimeout(() => textareaRef.current?.focus(), 0);
                  }
                }}
                title={isEditing ? "プレビュー表示に戻る" : "テキスト編集モードにする"}
                className={`${colors.borderStrong} border px-3 py-0.5 rounded-sm flex items-center transition-colors ${isEditing ? colors.activeText + " " + colors.activeBg : colors.textSubHover}`}
              >
                {isEditing ? "VIEW" : "EDIT"}
              </button>

              {/* Save Button */}
              <button
                onClick={handleSave}
                title="保存 (Ctrl+S)"
                className={`${colors.borderStrong} border px-3 py-0.5 rounded-sm ${colors.textSubHover} transition-colors flex items-center gap-1`}
              >
                <span className="opacity-50">[CTRL+S]</span> SAVE
              </button>

              <div className={`w-[1px] h-3 ${colors.borderStrong}`}></div>

              {/* Navigation Group */}
              {onNavigate && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => hasPrev && onNavigate('PREV')}
                    disabled={!hasPrev}
                    title="古いファイルへ"
                    className={`${colors.borderStrong} border px-3 py-0.5 rounded-sm flex items-center transition-colors ${hasPrev ? colors.textSubHover : "opacity-30 cursor-not-allowed"}`}
                  >
                    PREV
                  </button>
                  <button
                    onClick={() => hasNext && onNavigate('NEXT')}
                    disabled={!hasNext}
                    title="新しいファイルへ"
                    className={`${colors.borderStrong} border px-3 py-0.5 rounded-sm flex items-center transition-colors ${hasNext ? colors.textSubHover : "opacity-30 cursor-not-allowed"}`}
                  >
                    NEXT
                  </button>
                </div>
              )}
              </div>

            </div>
          </div>

          {/* Editor Body */}
          <div
            className={`flex-1 w-full flex justify-center py-8 px-6 ${panelBgClass} overflow-hidden group relative`}
          >
            {isVertical && (
              <>
                {/* Left Controls: End & Scroll Left */}
                <div
                  className="absolute left-4 top-1/2 -translate-y-1/2 flex flex-col items-center gap-3 opacity-0 group-hover:opacity-100 transition-opacity"
                  style={{ zIndex: 20 }}
                >
                  <button
                    onClick={scrollToEnd}
                    className={`p-2 rounded-full ${colors.borderStrong} border bg-black/5 dark:bg-white/5 hover:bg-black/15 dark:hover:bg-white/15 transition-colors flex items-center justify-center cursor-pointer shadow-sm`}
                    title="一番最後へ移動 (末尾)"
                  >
                    <ChevronsLeft size={24} className={textMainClass} />
                  </button>
                  <button
                    onMouseDown={() => startScroll(-1)}
                    onMouseUp={stopScroll}
                    onMouseLeave={stopScroll}
                    onTouchStart={() => startScroll(-1)}
                    onTouchEnd={stopScroll}
                    className={`p-2 rounded-full ${colors.borderStrong} border bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 transition-colors flex items-center justify-center cursor-pointer shadow-sm`}
                    title="左へスクロール (長押し)"
                  >
                    <ChevronLeft size={28} className={textMainClass} />
                  </button>
                </div>

                {/* Right Controls: Start & Scroll Right */}
                <div
                  className="absolute right-4 top-1/2 -translate-y-1/2 flex flex-col items-center gap-3 opacity-0 group-hover:opacity-100 transition-opacity"
                  style={{ zIndex: 20 }}
                >
                  <button
                    onClick={scrollToBeginning}
                    className={`p-2 rounded-full ${colors.borderStrong} border bg-black/5 dark:bg-white/5 hover:bg-black/15 dark:hover:bg-white/15 transition-colors flex items-center justify-center cursor-pointer shadow-sm`}
                    title="一番前へ移動 (先頭)"
                  >
                    <ChevronsRight size={24} className={textMainClass} />
                  </button>
                  <button
                    onMouseDown={() => startScroll(1)}
                    onMouseUp={stopScroll}
                    onMouseLeave={stopScroll}
                    onTouchStart={() => startScroll(1)}
                    onTouchEnd={stopScroll}
                    className={`p-2 rounded-full ${colors.borderStrong} border bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 transition-colors flex items-center justify-center cursor-pointer shadow-sm`}
                    title="右へスクロール (長押し)"
                  >
                    <ChevronRight size={28} className={textMainClass} />
                  </button>
                </div>
              </>
            )}

            <div
              className={`w-full h-full relative transition-all`}
              style={{ maxWidth: `${editorMaxWidth}px` }}
            >
              {content === "" && isEditing && (
                <div
                  className={`absolute top-0 left-0 ${textDimClass} font-bold pointer-events-none whitespace-pre-wrap select-none w-full`}
                  style={{
                    textAlign,
                    fontSize: `${textSize}px`,
                    fontFamily: textFont,
                    writingMode: isVertical ? "vertical-rl" : "horizontal-tb",
                  }}
                >
                  Type your text here...
                </div>
              )}
              {isEditing ? (
                <textarea
                  ref={textareaRef}
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  className={`w-full h-full bg-transparent resize-none outline-none ${textMainClass} thin-scrollbar relative z-10 font-sans`}
                  style={{
                    textAlign,
                    writingMode: isVertical ? "vertical-rl" : "horizontal-tb",
                    fontSize: `${textSize}px`,
                    fontFamily: textFont,
                    lineHeight: Number(editorLineHeight),
                  }}
                  spellCheck={false}
                />
              ) : (
                <div
                  ref={previewRef}
                  onDoubleClick={() => {
                    setIsEditing(true);
                    setTimeout(() => textareaRef.current?.focus(), 0);
                  }}
                  onClick={handlePreviewClick}
                  className={`w-full h-full overflow-auto outline-none ${textMainClass} thin-scrollbar relative z-10 font-sans select-text`}
                  style={{
                    textAlign,
                    writingMode: isVertical ? "vertical-rl" : "horizontal-tb",
                    fontSize: `${textSize}px`,
                    fontFamily: textFont,
                    lineHeight: Number(editorLineHeight),
                  }}
                  title="ダブルクリックで編集"
                >
                  {content.trim() === "" ? (
                    <div className={`${textDimClass} italic select-none`}>No content</div>
                  ) : (
                    <Markdown
                      remarkPlugins={[remarkGfm]}
                      components={markdownComponents}
                    >
                      {content}
                    </Markdown>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Footer Line */}
          <div
            className={`flex-none p-6 flex flex-col items-center justify-center text-[9px] ${colors.textDim} tracking-widest uppercase ${colors.panelBg}`}
          >
            <div>{content.length} CHARS • {isEditing ? "EDITING MODE" : "PREVIEW MODE (DOUBLE CLICK TO EDIT)"}</div>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
